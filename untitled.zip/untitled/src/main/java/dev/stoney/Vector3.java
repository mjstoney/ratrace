package dev.stoney;

public class Vector3 {
    public float x, y, z;
    public Vector3() {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
    }
    public Vector3(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public Vector3 add(Vector3 rhs) {
        return new Vector3(this.x + rhs.x, this.y + rhs.y, this.z + rhs.z);
    }

    public Vector3 subtract(Vector3 rhs) {
        return new Vector3(this.x - rhs.x, this.y - rhs.y, this.z - rhs.z);
    }

    public Vector3 multiply(float scalar) {
        return new Vector3(this.x * scalar, this.y * scalar, this.z * scalar);
    }

    public Vector3 divide(float scalar) {
        return new Vector3(this.x / scalar, this.y / scalar, this.z / scalar);
    }

    public float dot(Vector3 rhs) {
        return this.x * rhs.x + this.y * rhs.y + this.z * rhs.z;
    }

    public float magnitude() {
        return (float)Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    }

    public float magnitudeSq() {
        return this.x * this.x + this.y * this.y + this.z * this.z;
    }

    public void normalize() {
        float m = magnitude();
        this.x /= m;
        this.y /= m;
        this.z /= m;
    }
    public Vector3 normalized() {
        return this.divide(magnitude());
    }

    public static Vector3 lerpVectors(Vector3 a, Vector3 b, float dt) {
        return a.multiply(1 - dt).add(b.multiply(dt));
    }

    public String toString() {
        return "x: " + x + ", y: " + y + ", z: " + z;
    }
}
