package dev.stoney;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.Color;
public class Image {
    BufferedImage img;
    ImageIO imgIO;
    int w, h;
    int redMask = 0xFF0000, greenMask = 0xFF00, blueMask = 0xFF;
    Image(int w, int h) {
        this.w = w;
        this.h = h;
        img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);;
    }

    public void setPixel(int x, int y, int rgb) {
        img.setRGB(x, y, rgb);
    }

    public void initTest() {
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int r = x % 255;
                int g = y % 255;
                int b = (r + g) % 255;
                //int rgb = ((r&0x0ff)<<16)|((g&0x0ff)<<8)|(b&0x0ff);
                int c = new Color(r, g, b).getRGB();
                img.setRGB(x, y, c);
            }
    }

    public void writeImageToFile(String filename) {
        File output = new File(filename);
        try {
            ImageIO.write(img, "png", output);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
