package dev.stoney;

import java.util.ArrayList;

public class Scene {
    public Vector3 camera;
    public ImagePlane imagePlane;
    public ArrayList<Light> lights;
    public ArrayList<SceneObject> objects;

    Scene(Vector3 camera, ImagePlane ip, ArrayList<Light> lights, ArrayList<SceneObject> objects) {
        this.camera = camera;
        this.imagePlane = ip;
        this.lights = lights;
        this.objects = objects;
    }
}
