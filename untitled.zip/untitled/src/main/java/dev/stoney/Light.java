package dev.stoney;

public class Light {
    public Vector3 pos;
    public Color iAmb, iDiff, iSpec;
    public Light(Vector3 pos) {
        this.pos = pos;
        iAmb = new Color(0.5f, 0.5f, 0.5f);
        iDiff = new Color(0.5f, 0.5f, 0.5f);
        iSpec = new Color(0.5f, 0.5f, 0.5f);
    }

    public Light(Vector3 pos, Color iAmb, Color iDiff, Color iSpec) {
        this.pos = pos;
        this.iAmb = iAmb;
        this.iDiff = iDiff;
        this.iSpec = iSpec;
    }
}
