package dev.stoney;

public class Material {
    public Color kAmb, kDiff, kSpec;
    public float shininess;
    Material(Color kAmb, Color kDiff, Color kSpec, float shininess) {
        this.kAmb = kAmb;
        this.kDiff = kDiff;
        this.kSpec = kSpec;
        this.shininess = shininess;
    }
}
