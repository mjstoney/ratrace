package dev.stoney;

public class Color {
    public float r, g, b;
    public Color() {
        this.r = 0.5f;
        this.g = 0.5f;
        this.b = 0.5f;
    }
    public Color(float r, float g, float b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public Color add(Color rhs) {
        return new Color(this.r + rhs.r, this.g + rhs.g, this.b + rhs.b);
    }

    public Color subtract(Color rhs) {

        return new Color(this.r - rhs.r, this.g - rhs.g, this.b - rhs.b);
    }
    public Color multiply(Color rhs) {
        return new Color(this.r * rhs.r, this.g * rhs.g, this.b * rhs.b);
    }
    public Color multiple(float scalar) {
        return new Color(this.r * scalar, this.g * scalar, this.b*scalar).clamp();
    }
    public int rgbToInt() {
        /*
            Blue =  RGBint & 255
            Green = (RGBint >> 8) & 255
            Red =   (RGBint >> 16) & 255
         */
        // Assume color depth of 8bit
        int red = Math.round(this.r * 255);
        int green = Math.round(this.g * 255);
        int blue = Math.round(this.b * 255);
        return (red << 16) & 0x00FF0000 | (green << 8) & 0x0000FF00 | blue & 0x000000FF;
    }

    public Color clamp() {
        this.r = Math.max(0.0f, Math.min(this.r, 1.0f));
        this.g = Math.max(0.0f, Math.min(this.g, 1.0f));
        this.b = Math.max(0.0f, Math.min(this.b, 1.0f));
        return this;
    }

    public String toString() {
        return "R: " + this.r + "\tG: " + this.g + "\tB: " + this.b;
    }
}
