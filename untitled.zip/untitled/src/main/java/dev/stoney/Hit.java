package dev.stoney;

public class Hit {
    public float dist;
    public SceneObject obj;
    public Vector3 normal;
    public Hit(float d, SceneObject obj, Vector3 normal) {
        this.dist = d;
        this.obj = obj;
        this.normal = normal;
    }
}
