package dev.stoney;

public class RayTracer {
    Scene scene;
    Image image;
    int W, H;
    public RayTracer(Scene scene, int W, int H) {
        this.W = W;
        this.H = H;
        this.scene = scene;
        this.image = new Image(W, H);

    }

    public void trace() {
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                // Bidirectional lerp to find ray dir
                Vector3 top = Vector3.lerpVectors(scene.imagePlane.topLeft, scene.imagePlane.topRight, (float) x / W);
                Vector3 bot = Vector3.lerpVectors(scene.imagePlane.botLeft, scene.imagePlane.botRight, (float) x / W);
                Vector3 point = Vector3.lerpVectors(top, bot, (float) y / H);
                // Create Ray from camera to point on ImagePlane
                Ray ray = new Ray(scene.camera, point);

                // loop over all objects in scene.objects array
                for (SceneObject obj : scene.objects) {
                    // Check if ray hits obj, and return distance or -1 if no hit
                    float d = obj.earliestIntersection(ray);

                    if (d > -1.0f) {
                        // Store hit information in POJO
                        Hit hit = new Hit(d, obj, obj.getNormal(point));

                        // Incorporate lights
                        Color ambient = new Color(0f, 0f, 0f);
                        Color diffuse = new Color(0f, 0f, 0f);
                        Color specular = new Color(0f, 0f, 0f);
                        Color totalLight = new Color(0f, 0f, 0f);
                        for (Light light : scene.lights) {
                            Vector3 l = light.pos.subtract(point).normalized();
                            Vector3 n = obj.getNormal(point);

                            //Vector3 r = (n.multiply(2 * l.dot(n))).subtract(l);
                            float nCoeff = (2 * l.dot(n));
                            Vector3 rComponent1 = n.multiply(nCoeff);
                            Vector3 r = rComponent1.subtract(l);

                            Vector3 v = ray.orig.subtract(point).normalized();

                            ambient = ambient.add(light.iAmb.multiply(obj.material.kAmb));
                            diffuse = diffuse.add(light.iDiff.multiply(obj.material.kDiff).multiple(n.dot(l)));
                            specular = specular.add(light.iSpec.multiply(obj.material.kSpec).multiple((float) Math.pow(r.dot(v), obj.material.shininess)));
                            totalLight = (ambient.add(diffuse).add(specular)).clamp();
                        }
                        image.setPixel(x, y, totalLight.rgbToInt());
                    }
                }
            }
        }
        image.writeImageToFile("newTestImage.png");
    }
}
