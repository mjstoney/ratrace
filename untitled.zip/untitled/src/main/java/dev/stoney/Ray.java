package dev.stoney;

public class Ray {
    public Vector3 orig, dir;
    public Ray() {
        this.orig = new Vector3(0.0f, 0.0f, 0.0f);
        this.dir = new Vector3(1.0f, 0.0f, 0.0f);
    }

    Ray(Vector3 dir) {
        this.orig = new Vector3(0.0f, 0.0f, 0.0f);
        this.dir = dir;
    }

    public Ray(Vector3 orig, Vector3 dir) {
        this.orig = orig;
        this.dir = dir;
    }

    public Vector3 at(float dt) {
        return orig.add(dir.multiply(dt));
    }
}
