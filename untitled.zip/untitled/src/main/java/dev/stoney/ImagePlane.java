package dev.stoney;

public class ImagePlane {
    Vector3 topLeft, topRight, botLeft, botRight;
    ImagePlane(Vector3 tl, Vector3 tr, Vector3 bl, Vector3 br) {
        this.topLeft = tl;
        this.topRight = tr;
        this.botLeft = bl;
        this.botRight = br;
    }
}
