package dev.stoney;

public abstract class SceneObject {
public Material material;
    SceneObject(Material material) {
        this.material = material;
    }
    public abstract float earliestIntersection(Ray ray);
    public abstract Vector3 getNormal(Vector3 point);


}
