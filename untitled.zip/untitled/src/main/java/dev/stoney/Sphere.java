package dev.stoney;

public class Sphere extends SceneObject {
    Vector3 position;
    float radius;
    public Sphere(Vector3 pos, float r, Material material) {
        super(material);
        this.position = pos;
        this.radius = r;
    }
    @Override
    public float earliestIntersection(Ray ray) {
        // Ray: P = O + Vd
        // Sphere: || P - C ||^2 = r^2
        // Solve: || O - Vt - C ||^2 - r^2 = 0
        // Simplified to at^2 + bt + c = 0
        // where:
        //      a = V . V
        //      b = 2[V . (O - C)]
        //      c = (O - C) . (O - C) - r^2

        // Vectors
        Vector3 V = ray.dir;
        Vector3 O = ray.orig;
        Vector3 C = this.position;

        // Constants
        float a = V.dot(V);
        float b = 2 * (V.dot(O.subtract(C)));
        Vector3 c1 = O.subtract(C);
        float c = c1.dot(c1) - this.radius * this.radius;

        float determinant = b * b - 4 * a * c;
        if (determinant < 0) {
            return -1.0f;
        }
        float sol1 = (-b + (float) Math.sqrt(determinant)) / (2 * a);
        float sol2 = (-b - (float) Math.sqrt(determinant)) / (2 * a);

        return Math.min(sol1, sol2);
    }

    @Override
    public Vector3 getNormal(Vector3 point) {
        return point.subtract(this.position).normalized();
    }
}
