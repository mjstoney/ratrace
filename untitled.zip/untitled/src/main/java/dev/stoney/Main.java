package dev.stoney;

import java.util.ArrayList;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int W = 400 * 2, H = 300 * 2;
        float focalLength = 1.0f;


        Scene scene = new Scene(
                new Vector3(0f, 0f, 2f),
                new ImagePlane(
                        new Vector3(-0.4f, -0.3f, -0.5f),
                        new Vector3(0.4f, -0.3f, -0.5f),
                        new Vector3(-0.4f, 0.3f, -0.5f),
                        new Vector3(0.4f, 0.3f, -0.5f)),
                new ArrayList<Light>() {{
                    add(new Light(
                            new Vector3(-2.0f, -2.0f, 2.5f),
                            new Color(0.5f, 0.5f, 0.5f),
                            new Color(0.5f, 0.5f, 0.5f),
                            new Color(0.8f, 0.8f, 0.8f))
                            );
//                    add(new Light(
//                            new Vector3(-2.0f, -2.0f, 2.0f),
//                            new Color(0.5f, 0.5f, 0.5f),
//                            new Color(0.8f, 0.8f, 0.8f),
//                            new Color(1.0f, 1.0f, 1.0f)));
                }},
                new ArrayList<SceneObject>() {{
                    add(new Sphere(
                            new Vector3(0.0f, -0.0f, -100.0f),
                            80.0f,
                            new Material(
                                    new Color(1.0f, 1.0f, 1.0f),
                                    new Color(0.2f, 0.5f, 0.9f),
                                    new Color(0.5f, 0.5f, 0.5f),
                                    80.0f)));
                    add(new Sphere(
                            new Vector3(0.0f, 97.3f, -20.0f),
                            100.0f,
                            new Material(
                                    new Color(0.8f, 0.55f, 0.3f),
                                    new Color(0.8f, 0.55f, 0.3f),
                                    new Color(0.0f, 0.0f, 0.0f),
                                    0.0f)));
                    add(new Sphere(
                            new Vector3(0.0f, -0.0f, -0.8f),
                            1.0f,
                            new Material(
                                    new Color(0.5f, 0.1f, 0.5f),
                                    new Color(0.5f, 0.0f, 0.5f),
                                    new Color(0.5f, 0.5f, 0.5f),
                                    50.0f)));

                }});
        RayTracer tracer = new RayTracer(scene, W, H);
        tracer.trace();
    }

    public static int lerpInt(int a, int b, float dt) {
        return (int) ((1 - dt) * a + dt * b);
    }
}