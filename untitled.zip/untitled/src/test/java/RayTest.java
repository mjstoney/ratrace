import dev.stoney.Ray;
import dev.stoney.Vector3;
import org.junit.jupiter.api.Test;

public class RayTest {
    Ray r1 = new Ray(new Vector3(0.0f, 0.0f, 0.0f), new Vector3(1.0f, 1.0f, 1.0f));
    float dt = 2.0f;
    double epsilon = 1.4f / 10000.0f; // error

    @Test
    void testAt() {
        Vector3 res = r1.at(dt);
        assert(res.x - 2.0 < epsilon);
        assert(res.y - 2.0 < epsilon);
        assert(res.z - 2.0 < epsilon);
    }
}
