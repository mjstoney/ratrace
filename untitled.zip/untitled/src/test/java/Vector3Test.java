import dev.stoney.Vector3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Vector3Test {
    double epsilon = 1.4f / 10000.0f; // error
    Vector3 v0 = new Vector3(0.0f, 0.0f, 0.0f);
    Vector3 v1 = new Vector3(1.0f, 1.0f, 1.0f);
    Vector3 v2 = new Vector3(2.0f, 2.0f, 2.0f);
    float scalar = 2.0f;
    float dt = 0.5f;

    @Test
    void testAddVectors() {
         Vector3 res = v0.add(v1);

        assert(res.x - v1.x < epsilon);
        assert(res.y - v1.y < epsilon);
        assert(res.z - v1.z < epsilon);
    }

    @Test
    void testSubtractVectors() {
        Vector3 res = v0.subtract(v1);

        assert(res.x + v1.x < epsilon);
        assert(res.y + v1.y < epsilon);
        assert(res.z + v1.z < epsilon);
    }

    @Test
    void testMultiplyVector() {
        Vector3 res = v1.multiply(scalar);

        assert(res.x /scalar < v1.x + epsilon);
        assert(res.y /scalar < v1.y + epsilon);
        assert(res.z /scalar < v1.z + epsilon);
    }

    @Test
    void testDivideVector() {
        Vector3 res = v1.divide(scalar);

        assert(res.x * scalar < v1.x + epsilon);
        assert(res.y * scalar < v1.y + epsilon);
        assert(res.z * scalar < v1.z + epsilon);
    }


    @Test
    void testDotVectors() {
        float res = v1.dot(v2);
        assert(res - 6.0f < epsilon);
    }

    @Test
    void testMagnitude() {
        assert(v0.magnitude() < epsilon);
        assert(v1.magnitude() - 1.7320508f < epsilon);
    }

    @Test
    void testMagnitudeSq() {
        assert(v2.magnitudeSq() - 12.0 < epsilon);
    }

    @Test
    void testNormalize() {
        Vector3 testNormalize = new Vector3(3.0f, 3.0f, 3.0f);
        testNormalize.normalize();
        assert(testNormalize.magnitude() - 1.0f < epsilon);
    }

    @Test
    void testNormalized() {
        assert(v1.normalized().magnitude() - 1.0f < epsilon);
        assert(v2.normalized().magnitude() - 1.0f < epsilon);
    }

    @Test
    void testVectorToString() {
        Vector3 v1 = new Vector3(1.0f, 1.0f, 1.0f);
        String s1 = v1.toString();
        assertEquals(s1, "x: 1.0, y: 1.0, z: 1.0");
    }

    @Test
    void testLerpVectors() {
        Vector3 res = Vector3.lerpVectors(v0, v2, dt);
        assert(res.x - v1.x < epsilon);
        assert(res.y - v1.y < epsilon);
        assert(res.z - v1.z < epsilon);
        assert(res.magnitude() - 1.7320508f < epsilon);
    }
}
