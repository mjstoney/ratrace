import dev.stoney.Ray;
import dev.stoney.SceneObject;
import dev.stoney.Sphere;
import dev.stoney.Vector3;
import org.junit.jupiter.api.Test;

public class SphereTest {
    SceneObject sph1 = new Sphere(new Vector3(10.0f, 0.0f, 0.0f), 1.0f, null);
    Ray r1 = new Ray(new Vector3(0.0f, 0.0f, 0.0f), new Vector3(1.0f, 0.0f, 0.0f));
    float epsilon = 1.4f / 10000f;

    @Test
    void testEarliestIntersection() {
        assert(sph1.earliestIntersection(r1) - 9.0 < epsilon);
    }

}
