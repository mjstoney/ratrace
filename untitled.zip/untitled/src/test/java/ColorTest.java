import dev.stoney.Color;
import org.junit.jupiter.api.Test;

public class ColorTest {
    Color c1 = new Color(0.5f, 0.5f, 0.5f);
    Color c2 = new Color(0.5f, 0.5f, 0.5f);
    Color c3 = new Color(1.0f, 1.0f, 1.0f);
    double epsilon = 1.4f / 10000.0f; // error
    int white = 16777215;

    @Test
    void testAdd() {
        Color res = c1.add(c2);
        assert(res.r - 1.0f < epsilon);
        assert(res.g - 1.0f < epsilon);
        assert(res.b - 1.0f < epsilon);
    }

    @Test
    void testSubtract() {
        Color res = c1.subtract(c2);
        assert(res.r < epsilon);
        assert(res.g < epsilon);
        assert(res.b < epsilon);
    }

    @Test
    void testMultiply() {
        Color res = c1.multiply(c2);
        assert(res.r - 0.25 < epsilon);
        assert(res.g - 0.25 < epsilon);
        assert(res.b - 0.25 < epsilon);
    }

    @Test
    void testRgbToInt() {
        // 16777215 represents integer color white -> RGB(255, 255, 255);
        int test = c3.rgbToInt();
        assert((float) test - white < epsilon);

    }
}
